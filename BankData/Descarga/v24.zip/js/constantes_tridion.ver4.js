var urlRedirect= "/meta/redirect/info-navegador.jsp";
var dominioEntorno =  window.location.hostname ;
var contadorTridion=10;
var openLogin = "ol";